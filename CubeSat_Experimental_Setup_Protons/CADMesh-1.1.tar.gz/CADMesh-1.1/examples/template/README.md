#CADMesh Template
In the DetectorConstructor, set the filename/path to the CAD file you would like to load.
Assuming CADMesh has been installed, build the template, with the following commands:

    mkdir build
    cd build/
    cmake ..
    make

Run the example with the following command:

    ./cadmesh_template
 
